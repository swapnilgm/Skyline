/**
 * 
 */
package kdom.core;

/**
 * @author Swapnil
 *
 */
public enum Bounds {
	LOWERBOUND,
	UPPERBOUND
}
