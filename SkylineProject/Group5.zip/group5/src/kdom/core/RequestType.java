/**
 * 
 */
package kdom.core;

/**
 * @author Swapnil
 *
 */
public enum RequestType {
	MBR,
	KDOM,
	SIMPLE,
	DATA
}
