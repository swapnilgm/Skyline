/**
 * 
 */
package kdom.core;

/**
 * @author Swapnil
 *
 */
public enum Message {
	MID
}
