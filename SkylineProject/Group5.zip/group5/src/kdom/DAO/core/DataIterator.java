package kdom.DAO.core;

import java.util.Iterator;

import kdom.core.Tuple;

public interface DataIterator extends Iterator<Tuple> {

}
