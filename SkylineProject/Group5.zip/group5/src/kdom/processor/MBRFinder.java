/**
 * 
 */
package kdom.processor;

import kdom.core.MBR;

/**
 * @author Swapnil
 *
 */
public interface MBRFinder extends Runnable {
	
	public MBR getMbr();

}
